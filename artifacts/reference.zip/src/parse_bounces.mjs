import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quoted) {
      if (char === '"' && text[index + 1] === '"') {
        cell += '"';
        index += 1;
      } else if (char === '"') quoted = false;
      else cell += char;
    } else if (char === '"') quoted = true;
    else if (char === ",") { row.push(cell); cell = ""; }
    else if (char === "\n") {
      row.push(cell.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      cell = "";
    } else cell += char;
  }
  if (cell || row.length) {
    row.push(cell.replace(/\r$/, ""));
    rows.push(row);
  }
  const headers = rows.shift() ?? [];
  return rows
    .filter((values) => values.some((value) => value !== ""))
    .map((values) => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])));
}

function csvCell(value) {
  const text = String(value ?? "");
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function csvText(headers, rows) {
  return `${headers.join(",")}\n${rows
    .map((row) => headers.map((header) => csvCell(row[header])).join(","))
    .join("\n")}\n`;
}

function splitHeaderBody(text) {
  const match = /\r?\n\r?\n/.exec(text);
  if (!match) return [text, ""];
  return [text.slice(0, match.index), text.slice(match.index + match[0].length)];
}

function parseHeaders(text) {
  const unfolded = text.replace(/\r?\n[ \t]+/g, " ");
  const headers = {};
  for (const line of unfolded.split(/\r?\n/)) {
    const separator = line.indexOf(":");
    if (separator < 0) continue;
    const name = line.slice(0, separator).trim().toLowerCase();
    const value = line.slice(separator + 1).trim();
    headers[name] = headers[name] ? `${headers[name]}, ${value}` : value;
  }
  return headers;
}

function decodeQuotedPrintable(text) {
  const unfolded = text.replace(/=\r?\n/g, "");
  const binary = unfolded.replace(/=([0-9a-fA-F]{2})/g, (_, hex) =>
    String.fromCharCode(Number.parseInt(hex, 16)));
  return Buffer.from(binary, "latin1").toString("utf8");
}

function decodePartBody(body, encoding) {
  const normalizedEncoding = String(encoding ?? "").toLowerCase();
  if (normalizedEncoding === "base64") {
    return Buffer.from(body.replace(/\s/g, ""), "base64").toString("utf8");
  }
  if (normalizedEncoding === "quoted-printable") return decodeQuotedPrintable(body);
  return body;
}

function parseDeliveryFields(text) {
  const fields = parseHeaders(text);
  const recipientField = fields["final-recipient"] ?? "";
  const recipient = recipientField.includes(";")
    ? recipientField.slice(recipientField.indexOf(";") + 1).trim()
    : recipientField.trim();
  return {
    message_id: String(fields["original-message-id"] ?? "").replace(/^<|>$/g, ""),
    recipient: recipient.toLowerCase(),
    action: fields.action ?? "",
    status_code: fields.status ?? "",
    diagnostic_code: fields["diagnostic-code"] ?? "",
  };
}

function parseEmail(file, rawText) {
  const [outerHeaderText, outerBody] = splitHeaderBody(rawText);
  const outerHeaders = parseHeaders(outerHeaderText);
  const contentType = outerHeaders["content-type"] ?? "";
  const boundaryMatch = /boundary=(?:"([^"]+)"|([^;\s]+))/i.exec(contentType);
  if (!boundaryMatch) throw new Error(`multipart boundary missing in ${file}`);
  const boundary = boundaryMatch[1] ?? boundaryMatch[2];
  const rawParts = outerBody.split(`--${boundary}`).slice(1);
  const parts = [];
  for (let rawPart of rawParts) {
    rawPart = rawPart.replace(/^\r?\n/, "");
    if (rawPart.startsWith("--")) break;
    rawPart = rawPart.replace(/\r?\n$/, "");
    const [headerText, body] = splitHeaderBody(rawPart);
    const headers = parseHeaders(headerText);
    parts.push({
      content_type: (headers["content-type"] ?? "text/plain").split(";")[0].trim().toLowerCase(),
      transfer_encoding: (headers["content-transfer-encoding"] ?? "").toLowerCase(),
      decoded_body: decodePartBody(body, headers["content-transfer-encoding"]),
    });
  }
  const deliveryPart = parts.find((part) => part.content_type === "message/delivery-status");
  return {
    file,
    dsn_id: outerHeaders["x-dsn-id"] ?? path.basename(file, path.extname(file)),
    received_at_utc: outerHeaders["x-received-at"] ?? "",
    boundary,
    parts,
    delivery_fields: deliveryPart ? parseDeliveryFields(deliveryPart.decoded_body) : null,
    has_base64: parts.some((part) => part.transfer_encoding === "base64"),
    has_quoted_printable: parts.some((part) => part.transfer_encoding === "quoted-printable"),
  };
}

function addSeconds(timestamp, seconds) {
  return new Date(Date.parse(timestamp) + seconds * 1000).toISOString().replace(".000Z", "Z");
}

export function run(inputRoot, outputRoot) {
  const policy = JSON.parse(fs.readFileSync(path.join(inputRoot, "rules/bounce_policy.json"), "utf8"));
  const deliveryRows = parseCsv(fs.readFileSync(path.join(inputRoot, "data/delivery_log.csv"), "utf8"))
    .map((row) => ({ ...row, attempt_no: Number(row.attempt_no) }));
  const deliveryByMessage = new Map(deliveryRows.map((row) => [row.message_id, row]));
  const existingSuppression = parseCsv(
    fs.readFileSync(path.join(inputRoot, "data/existing_suppression.csv"), "utf8"),
  );
  const mailFiles = fs.readdirSync(path.join(inputRoot, "mail"))
    .filter((file) => file.toLowerCase().endsWith(".eml"))
    .sort();
  const messages = mailFiles.map((file) =>
    parseEmail(file, fs.readFileSync(path.join(inputRoot, "mail", file), "utf8")));

  const parsed = [];
  const suppressions = [];
  const retries = [];
  const exceptions = [];
  const seenDsnKeys = new Map();

  for (const message of messages) {
    const fields = message.delivery_fields ?? {
      message_id: "",
      recipient: "",
      action: "",
      status_code: "",
      diagnostic_code: "",
    };
    if (!fields.status_code) {
      exceptions.push({
        dsn_id: message.dsn_id,
        message_id: fields.message_id,
        recipient: fields.recipient,
        reason: "missing_status",
        detail: "message/delivery-status part does not contain Status",
      });
      continue;
    }
    const delivery = deliveryByMessage.get(fields.message_id);
    if (!delivery) {
      exceptions.push({
        dsn_id: message.dsn_id,
        message_id: fields.message_id,
        recipient: fields.recipient,
        reason: "unknown_message",
        detail: "message_id not found in delivery_log.csv",
      });
      continue;
    }
    const duplicateKey = [fields.message_id, fields.recipient, fields.status_code].join("\u0000");
    if (seenDsnKeys.has(duplicateKey)) {
      exceptions.push({
        dsn_id: message.dsn_id,
        message_id: fields.message_id,
        recipient: fields.recipient,
        reason: "duplicate_dsn",
        detail: `duplicate key message_id+recipient+status_code already seen in ${seenDsnKeys.get(duplicateKey)}`,
      });
      continue;
    }
    seenDsnKeys.set(duplicateKey, message.dsn_id);

    const statusRule = policy.status_rules.find((rule) => fields.status_code.startsWith(rule.prefix));
    if (!statusRule) {
      exceptions.push({
        dsn_id: message.dsn_id,
        message_id: fields.message_id,
        recipient: fields.recipient,
        reason: "unclassified_status",
        detail: `no status rule for ${fields.status_code}`,
      });
      continue;
    }
    const domain = fields.recipient.split("@").at(-1)?.toLowerCase() ?? "";
    const policyReason = statusRule.reason ?? statusRule.retry_tier;
    parsed.push({
      dsn_id: message.dsn_id,
      message_id: fields.message_id,
      recipient: fields.recipient,
      status_code: fields.status_code,
      action: fields.action,
      diagnostic_code: fields.diagnostic_code,
      class: statusRule.class,
      domain,
      policy_reason: policyReason,
    });

    if (statusRule.class === "permanent") {
      const value = statusRule.suppression_scope === "domain" ? domain : fields.recipient;
      const alreadyExists = existingSuppression.some((row) =>
        row.scope === statusRule.suppression_scope
        && row.value === value
        && row.reason === statusRule.reason);
      if (!alreadyExists) {
        suppressions.push({
          scope: statusRule.suppression_scope,
          value,
          reason: statusRule.reason,
          source_dsn_id: message.dsn_id,
          effective_at_utc: message.received_at_utc,
        });
      }
    } else if (statusRule.class === "transient") {
      retries.push({
        message_id: fields.message_id,
        recipient: fields.recipient,
        source_dsn_id: message.dsn_id,
        retry_tier: statusRule.retry_tier,
        next_attempt_no: delivery.attempt_no + 1,
        scheduled_at_utc: addSeconds(message.received_at_utc, statusRule.delay_seconds),
      });
    }
  }

  const domains = [...new Set(parsed.map((row) => row.domain))].sort();
  const domainSummary = domains.map((domain) => ({
    domain,
    parsed_bounces: parsed.filter((row) => row.domain === domain).length,
    permanent_bounces: parsed.filter((row) => row.domain === domain && row.class === "permanent").length,
    transient_bounces: parsed.filter((row) => row.domain === domain && row.class === "transient").length,
    suppression_updates: suppressions.filter((row) =>
      row.scope === "domain" ? row.value === domain : row.value.endsWith(`@${domain}`)).length,
    retry_rows: retries.filter((row) => row.recipient.endsWith(`@${domain}`)).length,
  }));
  const reportRoot = path.join(outputRoot, "reports");
  fs.rmSync(reportRoot, { recursive: true, force: true });
  fs.mkdirSync(reportRoot, { recursive: true });
  fs.writeFileSync(
    path.join(reportRoot, "parsed_bounces.csv"),
    csvText(["dsn_id", "message_id", "recipient", "status_code", "action", "diagnostic_code", "class", "domain", "policy_reason"], parsed),
  );
  fs.writeFileSync(
    path.join(reportRoot, "suppression_updates.csv"),
    csvText(["scope", "value", "reason", "source_dsn_id", "effective_at_utc"], suppressions),
  );
  fs.writeFileSync(
    path.join(reportRoot, "retry_plan.csv"),
    csvText(["message_id", "recipient", "source_dsn_id", "retry_tier", "next_attempt_no", "scheduled_at_utc"], retries),
  );
  fs.writeFileSync(
    path.join(reportRoot, "bounce_exceptions.csv"),
    csvText(["dsn_id", "message_id", "recipient", "reason", "detail"], exceptions),
  );
  fs.writeFileSync(
    path.join(reportRoot, "domain_summary.csv"),
    csvText(["domain", "parsed_bounces", "permanent_bounces", "transient_bounces", "suppression_updates", "retry_rows"], domainSummary),
  );
  const sourceRoot = path.join(outputRoot, "src");
  fs.mkdirSync(sourceRoot, { recursive: true });
  fs.copyFileSync(modulePath, path.join(sourceRoot, "parse_bounces.mjs"));
  return { parsed, suppressions, retries, exceptions, domainSummary };
}

const modulePath = fs.realpathSync(fileURLToPath(import.meta.url));
const invokedPath = process.argv[1] ? fs.realpathSync(process.argv[1]) : "";
if (modulePath === invokedPath) {
  const inputRoot = path.resolve(process.argv[2] ?? ".");
  const outputRoot = path.resolve(process.argv[3] ?? "output");
  try {
    const result = run(inputRoot, outputRoot);
    process.stdout.write(`${JSON.stringify({
      parsed: result.parsed.length,
      suppressions: result.suppressions.length,
      retries: result.retries.length,
      exceptions: result.exceptions.length,
      domains: result.domainSummary.length,
    })}\n`);
  } catch (error) {
    process.stderr.write(`${error.stack ?? error}\n`);
    process.exitCode = 1;
  }
}
