这批材料来自一次脱敏的营销邮件投递演练。mail目录保存收件服务器返回的multipart/report邮件，data/delivery_log.csv记录原始发送尝试，data/existing_suppression.csv是当前生效的抑制名单，rules/bounce_policy.json规定DSN字段、重复键、状态分类、抑制范围和重投延迟。

请完成starter/parse_bounces.mjs并保留run函数。运行npm run process:bounces后，Node.js入口会清理旧output并调用该函数。任务只处理本地文件，不连接SMTP服务，也不改写邮件、发送记录、既有抑制名单或策略文件。
