export async function run(inputRoot, outputRoot) {
  throw new Error("请实现退信解析和处置报表生成");
}
