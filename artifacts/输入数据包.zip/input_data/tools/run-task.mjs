import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { fileURLToPath, pathToFileURL } from "node:url";

const toolsDir = path.dirname(fileURLToPath(import.meta.url));
const inputRoot = path.resolve(toolsDir, "..");
const outputRoot = path.join(inputRoot, "output");
const candidatePath = path.join(inputRoot, "starter", "parse_bounces.mjs");

function fail(message, code) {
  fs.rmSync(outputRoot, { recursive: true, force: true });
  process.stderr.write(`${message}\n`);
  process.exit(code);
}

fs.rmSync(outputRoot, { recursive: true, force: true });

const requiredPaths = [
  "data/delivery_log.csv",
  "data/existing_suppression.csv",
  "rules/bounce_policy.json",
  "starter/parse_bounces.mjs",
];
for (const relativePath of requiredPaths) {
  if (!fs.existsSync(path.join(inputRoot, relativePath))) {
    fail(`缺少必需输入：${relativePath}`, 2);
  }
}
const mailRoot = path.join(inputRoot, "mail");
if (!fs.existsSync(mailRoot) || !fs.readdirSync(mailRoot).some((name) => name.toLowerCase().endsWith(".eml"))) {
  fail("mail目录中没有eml邮件", 2);
}

try {
  const moduleUrl = `${pathToFileURL(candidatePath).href}?run=${Date.now()}`;
  const candidate = await import(moduleUrl);
  if (typeof candidate.run !== "function") {
    fail("starter/parse_bounces.mjs必须导出run函数", 3);
  }
  await candidate.run(inputRoot, outputRoot);
  const expectedPaths = [
    "reports/bounce_exceptions.csv",
    "reports/domain_summary.csv",
    "reports/parsed_bounces.csv",
    "reports/retry_plan.csv",
    "reports/suppression_updates.csv",
    "src/parse_bounces.mjs",
  ];
  const actualPaths = [];
  const collect = (directory, prefix = "") => {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
      if (entry.isDirectory()) collect(path.join(directory, entry.name), relative);
      else actualPaths.push(relative);
    }
  };
  collect(outputRoot);
  actualPaths.sort();
  if (JSON.stringify(actualPaths) !== JSON.stringify(expectedPaths)) {
    fail(`交付成员不符：${actualPaths.join(",")}`, 5);
  }
  process.stdout.write("退信处置文件已生成\n");
} catch (error) {
  fail(error?.stack ?? String(error), 6);
}
